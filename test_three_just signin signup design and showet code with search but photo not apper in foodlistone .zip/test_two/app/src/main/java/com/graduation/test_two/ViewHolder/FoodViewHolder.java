package com.graduation.test_two.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.graduation.test_two.Interface.ItemClickListner;
import com.graduation.test_two.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FoodViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView maindishfoodtype;
    public ImageView maindishimageView;
    public ItemClickListner listner;

    public FoodViewHolder(@NonNull View itemView) {
        super(itemView);


        maindishimageView = (ImageView)itemView.findViewById(R.id.imagedescription);
        maindishfoodtype = (TextView) itemView.findViewById(R.id.maindishname);
    }


    public void setItemClickListner(ItemClickListner Listner)
    {

        this.listner= listner;
    }


    @Override
    public void onClick(View v) {
        listner.onClick(v,getAdapterPosition(),false);
    }
}
