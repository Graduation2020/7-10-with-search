package com.graduation.test_two;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.graduation.test_two.Prevalent.Prevalent;

import java.util.Arrays;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import io.paperdb.Paper;


public class signin extends AppCompatActivity {


    private static final int RC_SIGN_IN = 234;
    GoogleSignInClient mGoogleSignInClient;
    View va;

   // LoginButton loginButton;
    CallbackManager callbackManager;

    private TextView Register,forgotPassword;
    private Button Login,facebooklogin;
    private FirebaseAuth mAuth;
    private EditText textInputEditTextEmail;
    private EditText textInputEditTextPassword;
    private static final String EMAIL = "email";
    ProgressBar progressBar;
    CheckBox Remember_Me;
    SharedPreferences pref;
    SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();


        Remember_Me = (CheckBox) findViewById(R.id.remember);
        //Typeface face =Typeface.createFromAsset(getAssets(),"font/VastShadow-Regular.ttf");
       // Remember_Me.setTypeface(face);
        Paper.init(this);
//        SharedPreferences sharedPref = getSharedPreferences("checkbox",MODE_PRIVATE);
//        String checkbox = sharedPref.getString("remember","");
//
//
//        if(checkbox.equals("true"))
//        {
//            startActivity(new Intent(signin.this, MainActivity.class));
//        }
//        else if(checkbox.equals("fales"))
//        {
//            Toast.makeText(getBaseContext(), "Reason can not be blank", Toast.LENGTH_SHORT).show();
//        }
//
//      Remember_Me.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//          @Override
//          public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//
//
//              if (compoundButton.isChecked())
//              {
//                  SharedPreferences sharedPref = getSharedPreferences("checkbox",MODE_PRIVATE);
//                  SharedPreferences.Editor editor = sharedPref.edit();
//                  editor.putString("remember", "true");
//                  editor.commit();
//                  editor.apply();
//
//
//
//              }
//              else if(!compoundButton.isChecked())
//              {
//                  SharedPreferences sharedPref = getSharedPreferences("checkbox",MODE_PRIVATE);
//                  SharedPreferences.Editor editor = sharedPref.edit();
//                  editor.putString("remember", "false");
//                  editor.commit();
//                  editor.apply();
//                  Toast.makeText(getBaseContext(), "Reason can not be blank", Toast.LENGTH_SHORT).show();
//              }
//          }
//      });
//
//faceboock signin
        callbackManager = CallbackManager.Factory.create();


        //FacebookSdk.sdkInitialize(getApplicationContext());
     facebooklogin=(Button)findViewById(R.id.facebook_login_button);

       // loginButton.setReadPermissions("email", "public_profile");

        facebooklogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LoginManager.getInstance().logInWithReadPermissions(signin.this, Arrays.asList("email","public_profile"));
                LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        // App code

                        handleFacebookAccessToken(loginResult.getAccessToken());

                         Snackbar.make(va, "LOGIN Sucssess !!!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                 startActivity(new Intent(signin.this, testfacebook.class));


                    }

                    @Override
                    public void onCancel() {
                        // App code
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        // App code
                    }


                });


            }
        });

        // Callback registration
//        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
//            @Override
//            public void onSuccess(LoginResult loginResult) {
//                // App code
//                //startActivity(new Intent(signin.this, MainActivity.class));
//                handleFacebookAccessToken(loginResult.getAccessToken());
//
//
//            }
//
//            @Override
//            public void onCancel() {
//                // App code
//            }
//
//            @Override
//            public void onError(FacebookException exception) {
//                // App code
//            }
//        }
     // );


        mAuth = FirebaseAuth.getInstance();

////////////// signin with email and password only
        Register = (TextView) findViewById(R.id.register);
        Login = (Button) findViewById(R.id.login);
        //Register.setTypeface(face);
       // Login.setTypeface(face);
        textInputEditTextEmail = (EditText) findViewById(R.id.Email);
        textInputEditTextPassword = (EditText) findViewById(R.id.Password);

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(signin.this, signup.class));
            }
        });



        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                String email = textInputEditTextEmail.getText().toString().trim();
                String password = textInputEditTextPassword.getText().toString().trim();

                if (email.isEmpty()) {
                 textInputEditTextEmail.setError("Email is required");
//                    Toast.makeText(signin.this, "Email is required", Toast.LENGTH_SHORT).show();

                    textInputEditTextEmail.requestFocus();
                    return;
                }


                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    textInputEditTextEmail.setError("Please enter a valid email");
                    textInputEditTextEmail.requestFocus();
                    return;
                }

                if (password.isEmpty()) {
                    textInputEditTextPassword.setError("Password is required");
                    textInputEditTextPassword.requestFocus();
                    return;
                }

//                if (password.length() < 6) {
//                    textInputEditTextPassword.setError("Minimum lenght of password should be 6");
//                    textInputEditTextPassword.requestFocus();
//                    return;
//                }
                if (password.isEmpty() || password.length() < 8  || !(password.matches(".*[0-9].*")) ||  !(password.matches(".*[A-Z].*") ||  password.matches(".*[a-z].*") )) {
                    textInputEditTextPassword.setError("password must be at least 8 (charcter , numeric)");
                    textInputEditTextPassword.requestFocus();
                    return;
                }


                if (Remember_Me.isChecked())
                {
                    Paper.book().write(Prevalent.useremailkey,email);
                    Paper.book().write(Prevalent.userpasswordkey,password);


                }

                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(signin.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {

                            checkEmailVerification();

                        } else {

                            Snackbar.make(v, "LOGIN Failed !!!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        }
                    }
                });

//                String st1=textInputEditTextEmail.getText().toString();
//                String pa1=textInputEditTextPassword.getText().toString();
//
//                pref = PreferenceManager.getDefaultSharedPreferences(signin.this);
//                SharedPreferences.Editor editor = pref.edit();
//                editor.putString("st", st1);
//                editor.putString("pa", pa1);
//                editor.apply();
//                Log.d("", pref.getString("password", ""));

            }//end onclick


        });
/////////////// signin using google
        //Then we need a GoogleSignInOptions object
        //And we need to build it as below
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(getString(R.string.default_web_client_id)).requestEmail().build();

        //Then we will get the GoogleSignInClient object from GoogleSignIn class
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        //Now we will attach a click listener to the google_sign_in_button
        //and inside onClick() method we are calling the signIn() method that will open
        //google sign in intent 
        findViewById(R.id.google_sign_in_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn();
            }
        });



        forgotPassword = (TextView)findViewById(R.id.forgot_password);
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(signin.this, Forget_Password.class));
            }
        });

    }



//functions
    //for google and facebook
        protected void onStart() {
            super.onStart();

            if (mAuth.getCurrentUser() != null) {

            }

        }

//for google
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);

        //if the requestCode is the Google Sign In code that we defined at starting
        if (requestCode == RC_SIGN_IN) {
            FirebaseUser firebaseUser =  mAuth .getInstance().getCurrentUser();

            //Getting the GoogleSignIn Task
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                //Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);

                //authenticating with firebase
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                Toast.makeText(signin.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }


    }
//fpr fb
    private void handleFacebookAccessToken(AccessToken token) {
        Log.d("", "handleFacebookAccessToken:" + token);

        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("", "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                           // updateUI();
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("", "signInWithCredential:failure", task.getException());
                            Toast.makeText(signin.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                          //  updateUI(null);
                        }

                        // ...
                    }
                });
    }

    //for google
    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        Log.d("", "firebaseAuthWithGoogle:" + acct.getId());

        //getting the auth credential
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);

        //Now using firebase we are signing in the user here

        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d("", "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(signin.this, "User Signed In !!! Welcome ^_^", Toast.LENGTH_SHORT).show();
                           // Snackbar.make(va, "User Signed In !!!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                            startActivity(new Intent(signin.this, Home_Window.class));
                        }

                        else {
                            // If sign in fails, display a message to the user.
                            Log.w("", "signInWithCredential:failure", task.getException());
                            Toast.makeText(signin.this, "Authentication failed. !!!", Toast.LENGTH_SHORT).show();
                           // Snackbar.make(va, "Authentication failed. !!!", Snackbar.LENGTH_LONG).setAction("Action", null).show();

                        }
                    }
                });
    }

//for google
    //this method is called on click
    private void signIn() {
        //getting the google signin intent
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();

        //starting the activity for result
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

//forloginwithemailand pass
    private void checkEmailVerification(){

        FirebaseUser firebaseUser =  mAuth .getInstance().getCurrentUser();
        Boolean emailflag = firebaseUser.isEmailVerified();

        //startActivity(new Intent(signin.this, MainActivity.class));

        if(emailflag){
            finish();
            startActivity(new Intent(signin.this, Home_Window.class));
            //Snackbar.make(va, "Welcome ^_^ !!!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
          // Prevalent.currentOnlineuser = customer;

            Toast.makeText(signin.this, "Welcome ^_^ ", Toast.LENGTH_SHORT).show();

        }else{
           // Snackbar.make(va, "Verify your email please !!!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
            Toast.makeText(signin.this, "Verify your email please !!", Toast.LENGTH_SHORT).show();

            mAuth.signOut();
        }
    }


}


